import { createStore } from 'vuex'

export default createStore({
  state: {
    background: 'white',
    currency: 'сум'
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
