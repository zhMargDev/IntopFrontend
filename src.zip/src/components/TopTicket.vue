<template>
    <div id="ticket">
        <img src="@/assets/svg_icons/top_ticket.svg" alt="Top" >
    </div>
</template>

<style scoped>
#ticket{
    width: 44px;
    height: 19px;
    background: #000000;
    border: 2px solid #FFDD1F;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>