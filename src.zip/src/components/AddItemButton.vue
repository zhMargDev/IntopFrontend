<template>
    <button>
        Добавить товар
    </button>
</template>

<style scoped>
button{
    border: 0;
    height: 30px;
    background: #F16A26;
    border-radius: 8px;
    font-weight: 500;
    font-size: 12px;
    color: #FFFFFF;
    margin: auto 0;
    white-space: nowrap;
    padding: 0 20px;
    cursor: pointer;
}
</style>