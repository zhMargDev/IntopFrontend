<template>
    <div >
        <img src="@/assets/svg_icons/statistics.svg" alt="Statistics icon">
        <p>Продавайте на INTOP</p>
        <img src="@/assets/svg_icons/checked.svg" alt="Checked icon">
    </div>
</template>

<style scoped>
div{
    display: flex;
    gap: 7px;
    align-items: center;
}
img{
    width: 20px;
    height: 20px;
}
p{
    font-weight: 600;
    font-size: 12px;
    color: #000000;
    white-space: nowrap;
}
</style>